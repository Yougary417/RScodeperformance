
classdef rs
    methods (Static)
        % copies the entire polynomial
        function polynom = code_2_poly(code, len)
            poly = poly_factory();
            polynom = poly.poly_clear();

            for i = 1:len
                polynom.coeff(len - i + 1) = code(i);
            end

            polynom.degree = len - 1;
            polynom = poly.poly_normalize(polynom);
        end

        % always copy from higher bits. only copy message, not parity
        function codeword = poly_2_code(polynom, len)
            codeword = zeros(1, len);
            for i = 1 : len
                codeword(i) = polynom.coeff(polynom.degree + 1 + 1 - i);
            end
        end

        % for generating polynomial, b could be 0 or 1.
        function poly_res = make_gen_poly(rs_gp_n, b)
            poly = poly_factory();
            poly_xa = poly.poly_clear();
            poly_res = poly.poly_clear();
        
            poly_res.coeff(0 + 1) = 1;
            % (x - a^i)
            poly_xa.degree = 1;
            poly_xa.coeff(1 + 1) = 1;
        
            for i = 0:rs_gp_n-1
                % get a^i
                gf_an = poly.gf.gf2p8_pow(b + i);
                % fprintf("%d\n", gf_an);
                poly_xa.coeff(0 + 1) = poly.gf.gf2p8_neg(gf_an);

                poly_res = poly.poly_mul(poly_res, poly_xa);
            end
        end

        function [encoded] = rs_encode(message, code_len, msg_len, genpoly)
            poly = poly_factory();
            dividend = poly.poly_clear();
            for i = 1:msg_len
                dividend.coeff(code_len + 1 - i) = message(i);
            end
            dividend.degree = code_len - 1;
            dividend = poly.poly_normalize(dividend);

            rs_gp_n = code_len - msg_len;
            % actual encode
            [~, ~, rem] = poly.poly_div(dividend, genpoly);
            rem_codeword = zeros(1, rs_gp_n);
            for i = 1:rs_gp_n
                rem_codeword(i) = rem.coeff(rs_gp_n + 1 - i);
            end

            encoded = [message, rem_codeword];
        end
        
        % decoded results, total number of errors (-1) if not able to
        % correct
        function [decoded, cnumerr] = rs_decode(codeword, code_len, msg_len, genpoly)
            poly = poly_factory();
            syn_p = poly.poly_clear(); % syndrome

            % assumption: the front of the codeword has higher degree
            % so flip
            code_p = rs.code_2_poly(codeword, code_len);
            
            % syndrome
            rs_gp_n = code_len - msg_len;
            for i = 0:rs_gp_n-1
                sub_result = poly.poly_subst(code_p, poly.gf.gf2p8_pow(i));
                syn_p.coeff(rs_gp_n - i) = sub_result;
                %fprintf("C(a^%d) = %d, a^%d\n", i, sub_result, poly.gf.gf2p8_ind(sub_result));
            end
            syn_p.degree = rs_gp_n - 1;
            syn_p = poly.poly_normalize(syn_p);

            % syndrome 0? zero codeword
            if poly.poly_iszero(syn_p)
                decoded = rs.poly_2_code(code_p, msg_len);
                cnumerr = 0;
                return;
            end
            % try to decode. If no errors (remainder 0), return
            [~, ~, rem] = poly.poly_div(code_p, genpoly);
            if poly.poly_iszero(rem)
                % all good!
                decoded = rs.poly_2_code(code_p, msg_len);
                cnumerr = 0;
                return;
            end

            % X^(2*t)
            x_2t = poly.poly_clear();
            x_2t.degree = rs_gp_n;
            x_2t.coeff(rs_gp_n + 1) = 1;

            [sigma, omega, ~] = poly.poly_euclid(x_2t, syn_p, rs_gp_n / 2);

            sigma = poly.poly_neg(sigma);

            dsigma = poly.poly_diff(sigma);

            errors = 0;
            i = 0;
            while (i < code_len && errors < rs_gp_n / 2)
                an = poly.gf.gf2p8_pow(i);

                sub = poly.poly_subst(sigma, an);
                if sub == 0
                    % error position
                    errors = errors + 1;

                    e = poly.gf.gf2p8_div(poly.poly_subst(omega, an), poly.poly_subst(dsigma, an));
                    c = codeword(code_len - i);
                    if c < 0 || c > 255
                        error("c is not uint8");
                    end
                    c = cast(c, 'uint8');
                    n = poly.gf.gf2p8_sub(c, e);
                    codeword(code_len - i) = n;
                    code_p.coeff(i + 1) = n;
                end

                i = i + 1;
            end

            % if errors == 0
            %     error("expected codeword errors, but found none.");
            % end

            code_p.degree = code_len - 1;
            code_p = poly.poly_normalize(code_p);
            [~, ~, rem] = poly.poly_div(code_p, genpoly);
            decoded = codeword(1:msg_len);
            if ~poly.poly_iszero(rem)
                % could not fix errors
                cnumerr = -1;
            else
                cnumerr = errors;
            end
        end
    end
end