clear
clc

% Eb/N0 settings
EbN0_dB = 0:0.5:10;
EbN0 = 10.^(EbN0_dB / 10);

% Parameters
num_trials = 200; % Increase for more accuracy
symbol_bits = 8;
rs_k = e2e.rs_K;
rs_n = e2e.rs_N;
R_rs = rs_k / rs_n;
R_cc = 1/2;
R_total = R_rs * R_cc;

BER = zeros(size(EbN0));
MER = zeros(size(EbN0));

for i = 1:length(EbN0)
    N0 = 1 / (2 * R_total * EbN0(i));
    sigma = sqrt(N0);
    bit_errors = 0;
    msg_errors = 0;
    total_bits = 0;

    for t = 1:num_trials
        % Generate random message
        messages = randi([0 255], e2e.interleaver_rows, rs_k);

        % RS encode
        codewords = e2e.rs_encode_block(messages);

        % Interleave and convert to bits
        cc_msg = e2e.cc_interleave_reshape(codewords, false);

        % CC encode
        cc_codewords = e2e.cc_encode_block(cc_msg);
        cc_stream = e2e.cc_block_to_stream(cc_codewords);

        % BPSK modulation
        tx = 1 - 2 * cc_stream;

        % AWGN channel
        noise = sigma * randn(size(tx));
        rx = tx + noise;

        % Soft-decision CC decode
        cc_codewords_rx = e2e.cc_stream_to_block(rx, false);
        [cc_msg_decoded, ~] = e2e.cc_decode_block(cc_codewords_rx, @cc.diff_soft);

        % Deinterleave to RS symbols
        rs_input = e2e.cc_interleave_reshape_inv(cc_msg_decoded, false);

        % RS decode
        [decoded, ~] = e2e.rs_decode_block(rs_input);

        % Bit error comparison
        bits_orig = de2bi(messages', symbol_bits, 'left-msb')';
        bits_dec = de2bi(decoded', symbol_bits, 'left-msb')';

        err = sum(bits_orig(:) ~= bits_dec(:));
        bit_errors = bit_errors + err;
        msg_errors = msg_errors + (err > 0);
        total_bits = total_bits + numel(bits_orig);
    end

    BER(i) = bit_errors / total_bits;
    MER(i) = msg_errors / num_trials;
    fprintf('Eb/N0 = %.1f dB | BER = %.4e | MER = %.4f\n', EbN0_dB(i), BER(i), MER(i));
end

% Plotting
figure;
semilogy(EbN0_dB, BER, '-ro', EbN0_dB, MER, '-bs', 'LineWidth', 2);
grid on;
xlabel('E_b/N_0 (dB)');
ylabel('Error Rate');
legend('Bit Error Rate (BER)', 'Message Error Rate (MER)', 'Location', 'southwest');
title('Concatenated RS + Interleaver + CC over AWGN: BER and MER');
