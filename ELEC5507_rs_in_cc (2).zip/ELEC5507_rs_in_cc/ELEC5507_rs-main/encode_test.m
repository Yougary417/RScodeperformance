            messages = zeros(10, 239);
            for i = 1:10
                for j = 1:239
                    messages(i, j) = mod((i - 1 + j), 256); %uint8
                end
            end
            cc_tail_zeros = true;

            % step 1: rs encode
            codewords = e2e.rs_encode_block(messages);
            decoded_msgs = e2e.rs_decode_block(codewords);

            assert(isequal(messages, decoded_msgs))

            % step 2: interleave, and transform from byte to bit
            cc_msg = e2e.cc_interleave_reshape(codewords, cc_tail_zeros);
            codewords_interleave_res = e2e.cc_interleave_reshape_inv(cc_msg, cc_tail_zeros);

            assert(isequal(codewords, codewords_interleave_res));

            % step 3: cc encode
            cc_codewords = e2e.cc_encode_block(cc_msg);
            cc_msg_decoded = e2e.cc_decode_block(cc_codewords, @cc.diff_hard);

            assert(isequal(cc_msg, cc_msg_decoded));

            % step 4: transform into a single array, to feed into the
            % channel for testing
            cc_code_stream = e2e.cc_block_to_stream(cc_codewords);
            cc_codeword_res = e2e.cc_stream_to_block(cc_code_stream, cc_tail_zeros);

            assert(isequal(cc_codewords, cc_codeword_res))