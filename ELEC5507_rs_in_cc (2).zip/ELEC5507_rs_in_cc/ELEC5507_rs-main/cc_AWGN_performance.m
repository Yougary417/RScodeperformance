clear
clc

% Parameters
constraint_len = 7;
g0 = 79;   % octal 117
g1 = 109;  % octal 155
[trans, outputs] = cc.generate_conv_matrices(constraint_len, [g0, g1]);
state_num = size(trans, 1);
tail = constraint_len - 1;

k = 1000;               % Message length
num_trials = 1e3;       % Per SNR point
EbN0_dB = 0:0.5:10;     % SNR in dB
EbN0 = 10.^(EbN0_dB/10);
R = 1/2;                % Code rate for (2,1)

BER = zeros(size(EbN0));
MER = zeros(size(EbN0));

for i = 1:length(EbN0)
    N0 = 1 / (2 * R * EbN0(i));
    sigma = sqrt(N0);
    bit_errors = 0;
    msg_errors = 0;
    total_bits = 0;

    for t = 1:num_trials
        % Message + tail
        msg = randi([0 1], 1, k);
        msg_pad = [msg, zeros(1, tail)];

        % Encode
        codeword = cc.conv_encode(msg_pad, constraint_len, outputs, 2);

        % BPSK modulation
        tx = 1 - 2 * codeword;  % 0 -> +1, 1 -> -1

        % Add AWGN
        noise = sigma * randn(size(tx));
        rx = tx + noise;

        % Soft-decision decode
        [decoded, ~, ~] = cc.viterbi_decode(state_num, trans, outputs, rx, @cc.diff_soft);
        decoded = decoded(1:k);  % remove tail

        % Errors
        errors = sum(decoded ~= msg);
        bit_errors = bit_errors + errors;
        msg_errors = msg_errors + (errors > 0);
        total_bits = total_bits + k;
    end

    BER(i) = bit_errors / total_bits;
    MER(i) = msg_errors / num_trials;
    fprintf("Eb/N0 = %.1f dB | BER = %.5e | MER = %.4f\n", EbN0_dB(i), BER(i), MER(i));
end

% Plot
figure;
semilogy(EbN0_dB, BER, '-ro', EbN0_dB, MER, '-bs', 'LineWidth', 2);
grid on;
xlabel('E_b/N_0 (dB)');
ylabel('Error Rate');
legend('Bit Error Rate (BER)', 'Message Error Rate (MER)', 'Location', 'southwest');
title('Convolutional Code (2,1,6) over AWGN: BER and MER');
