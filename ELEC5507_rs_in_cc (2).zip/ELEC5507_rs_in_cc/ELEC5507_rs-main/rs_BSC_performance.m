clear
clc

% RS参数
rs_N = 255;
rs_K = 239;
m = 8;
t = (rs_N - rs_K) / 2;
num_bits = rs_K * m;
primpoly = 285;

% 自定义生成多项式
my_genpoly = rs.make_gen_poly(rs_N - rs_K, 1);

% 信道参数
p_values = [1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 1e-3];
num_trials_list = [1e5 5e4 2e4 1e4 5e3 2e3 1e3];

% 结果存储
MER = zeros(size(p_values));
BER = zeros(size(p_values));

% 并行池启动（如未启动）
if isempty(gcp('nocreate'))
    parpool('local');
end

% 开始每个 p 值仿真
for idx = 1:length(p_values)
    p = p_values(idx);
    num_trials = num_trials_list(idx);
    fprintf('Testing p = %.1e with %d trials...\n', p, num_trials);

    % 初始化误差数组
    msg_err_vec = zeros(1, num_trials);
    bit_err_vec = zeros(1, num_trials);

    % 并行 trial 仿真
    parfor trial = 1:num_trials
        local_msg_err = 0;
        local_bit_err = 0;

        % 随机消息
        message = randi([0, 255], 1, rs_K, 'uint8');
        codeword = rs.rs_encode(message, rs_N, rs_K, my_genpoly);

        % 转换为比特并通过BSC扰动
        bits = de2bi(codeword, m, 'left-msb')';
        tx_bits = bits(:)';
        flip = rand(size(tx_bits)) < p;
        rx_bits = xor(tx_bits, flip);

        % 转换回符号
        rx_matrix = reshape(rx_bits, m, [])';
        received = bi2de(rx_matrix, 'left-msb')';
        received = uint8(received);

        % 解码
        [decoded, status] = rs.rs_decode(received, rs_N, rs_K, my_genpoly);

        % 原始消息比特
        orig_bits = de2bi(message, m, 'left-msb')';
        orig_bits = orig_bits(:)';

        if status == -1 || length(decoded) ~= rs_K
            % 解码失败：用扰动后的信息部分估计bit error
            rx_info = rx_matrix(1:rs_K, :)';
            rx_info_bits = rx_info(:)';
            local_msg_err = 1;
            local_bit_err = sum(orig_bits ~= rx_info_bits);
        else
            % 解码成功，比较结果
            dec_bits = de2bi(decoded, m, 'left-msb')';
            dec_bits = dec_bits(:)';
            local_bit_err = sum(orig_bits ~= dec_bits);
            if any(decoded ~= message)
                local_msg_err = 1;
            end
        end

        msg_err_vec(trial) = local_msg_err;
        bit_err_vec(trial) = local_bit_err;
    end

    % 累加统计结果
    MER(idx) = sum(msg_err_vec) / num_trials;
    BER(idx) = sum(bit_err_vec) / (num_trials * num_bits);

    fprintf("p = %.1e, MER = %.3e, BER = %.3e\n", p, MER(idx), BER(idx));
end

% 绘图
figure;
semilogx(p_values, MER, 'o-', 'LineWidth', 2); hold on;
semilogx(p_values, BER, 's-', 'LineWidth', 2);
grid on;
xlabel('BSC 概率 p');
ylabel('错误率');
legend('MER (消息错误率)', 'BER (比特错误率)');
title('自定义 RS(255,239) 解码器在 BSC 信道下的性能 (并行)');
