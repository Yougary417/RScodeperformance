clear
clc

% === Custom Convolutional Code Parameters ===
constraint_len = 7;
g0 = 79;   % octal 117
g1 = 109;  % octal 155

[trans, outputs] = cc.generate_conv_matrices(constraint_len, [g0, g1]);
state_num = size(trans, 1);
tail = constraint_len - 1;

% === Simulation Parameters ===
k = 1000;                                 % Message length in bits
p_vals = logspace(-2.25, -1, 9);            % BSC error probabilities                        % Number of trials per p

BER_custom = zeros(size(p_vals));        % Bit Error Rate
MER_custom = zeros(size(p_vals));        % Message Error Rate

% Start parallel pool if not already running
if isempty(gcp('nocreate'))
    parpool('local');
end

% Loop over each BSC probability value
for i = 1:length(p_vals)
    p = p_vals(i);
    if p <= 1e-2
    num_trials = 2e4; 
    else
    num_trials = 1e4;    
    end
    bit_err_vec = zeros(1, num_trials);
    msg_err_vec = zeros(1, num_trials);
    parfor t = 1:num_trials
        % Generate random message and append tail bits
        msg = randi([0 1], 1, k);
        msg_pad = [msg, zeros(1, tail)];

        % Custom convolutional encoding
        cc_code = cc.conv_encode(msg_pad, constraint_len, outputs, 2);

        % BSC channel simulation
        noise = rand(size(cc_code)) < p;
        received = mod(cc_code + noise, 2);

        % Custom Viterbi hard-decision decoding
        [decoded, ~, ~] = cc.viterbi_decode(state_num, trans, outputs, received, @cc.diff_hard);
        decoded = decoded(1:k);  % Remove tail bits

        % Error counting
        err = sum(decoded ~= msg);
        bit_err_vec(t) = err;
        msg_err_vec(t) = err > 0;
    end

    % Compute BER and MER for this p
    BER_custom(i) = sum(bit_err_vec) / (num_trials * k);
    MER_custom(i) = sum(msg_err_vec) / num_trials;

    fprintf("p = %.1e | BER = %.4e | MER = %.4e\n", p, BER_custom(i), MER_custom(i));
end

% === Plot BER and MER ===
figure;
semilogx(p_vals, BER_custom, '-ro', 'LineWidth', 2); hold on;
semilogx(p_vals, MER_custom, '-rs', 'LineWidth', 2);
grid on;
xlabel('BSC Transition Probability (p)');
ylabel('Error Rate');
legend('BER - Custom', 'MER - Custom', 'Location', 'southwest');
title('(2,1,6) Custom Convolutional Decoder over BSC');
yticks = 10.^(-5:0);
set(gca, 'YTick', yticks);
set(gca, 'YScale', 'log');
ylim([1e-7 1]);

