function encoded_info = rs_encoder(x, n, k, gen_poly, index, alpha_power)

        % x : symbol(integer) input
        % encoded_output : encoded symbols(integer) output
        
        %generator polynomial by primitive polynomial. for
        %p(x)=x^8+x^4=+x^3+x^2+1, it is 285(256+16+8+4+1)
        
        %for RS(255,239), GF(2^8), L = 2*t+1 = 2*8+1 = 17
        L = length(gen_poly);
        
        %initial register vector
        reg_v = zeros(1, L - 1, 'uint16');
            
        for i = 1:k
        
          % GF Adder, bitxor the last value of shift register and current input
          % value. fb means feedback
          fb = bitxor(reg_v(L-1), x(i));
        
          % GF multiplication, multiply fb with every generator polynomial coefficient
          if fb == 0 
          new_coef = zeros(1, L - 1);  % 
          else
          alpha_index = mod((index(fb+1)+index(gen_poly(1:L-1)+1)-2), n);
          new_coef = alpha_power(alpha_index + 1);
          end
          new_coef = uint16(new_coef);

          % GF Adders, with new coefficient, bitxor it with the every previous shift
          % register values, then shift to the right by 1 position
          reg_v = bitxor(new_coef, [uint16(0), reg_v(1:L-2)]);
        end
        
        % output is the orginal message + fliped final shift regsiter value (parity bits from high to low)
        encoded_info = [x fliplr(reg_v(1:L-1))];

end

