clear
clc

% Set RS code parameters:
n = 255;    % code length 
k = 239;    % information length
m = 8;      % number of bits per symbol
t = (n-k)/2; % maximum corrected bits
prim_poly = 285; % primitive polynomial
prim_poly_2 = double(de2bi(prim_poly, m+1, 'left-msb'));
offset = 1; % offset in generator polynomial formula

% calculate alpha power
alpha = gf(2, m, prim_poly); % primitive element 'alpha' of GF(2^m)
alpha_power = alpha.^(0:n);
ap = alpha_power.x;

% find a GF element in alpha_power array (find its exponent based on index)
index_gf_element = zeros(1, n+1);
for i = 2:n + 1
  index_gf_element(i) = find(i-1 == ap(1:n));
end

% obtain generator polynominal coefficients
gp = rsgenpoly(n, k, prim_poly, offset);
gen_poly = fliplr(gp.x);
rs_gp_n = n-k;
my_genpoly = rs.make_gen_poly(rs_gp_n, 1);

%test
p_list = [0.0001 0.00025 0.0005 0.00075 0.001 0.0025 0.005]; % probability p list
t_count = 1000; %number of transmission
error_bits = zeros(1,length(p_list)); %RS coded bit error number
error_msg = zeros(1,length(p_list));  %RS coded message error number
for i = 1:length(p_list)
    for j = 1:t_count
        % generate random 1x239 message matrix in decimal [0~255]
        rand_msg = randi([0, 255], 1, k, 'uint16');
        % convert to bits
        rand_msg_bits = de2bi(rand_msg, m, 'left-msb')'; 
        % reshape to a column vector
        rand_msg_bits_col = reshape(rand_msg_bits, m*k, 1);        
        
        % encode msg
        encoded_msg = rs_encoder(rand_msg, n, k, gen_poly, index_gf_element, ap);     
        % convert to bits
        encoded_bits = de2bi(encoded_msg, m , 'left-msb')';  
        % reshape to a column vector
        encoded_bits_col = reshape(encoded_bits, m*n, 1);

        %transmission in BSC channel with RS
        noise = rand(size(encoded_bits_col)) < p_list(i);
        received_bits_rs = xor(encoded_bits_col, noise);

        % decode msg
        received_bits = reshape(received_bits_rs, m, n);
        received_msg = bi2de(received_bits','left-msb');
        received_msg = received_msg';
        if any(received_msg(1:k) ~= rand_msg)
            [decoded_msg, errs_num] = rs.rs_decode(received_msg, n, k, my_genpoly);
        else
            decoded_msg = received_msg(1:k);
        end

        %calculate bit error rate and message error rate
        if any(decoded_msg ~= rand_msg)
            error_msg(i) = error_msg(i) + 1;
        end
        decoded_msg_bits = de2bi(decoded_msg, m, 'left-msb')'; 
        decoded_msg_bits_col = reshape(decoded_msg_bits, m*k, 1); 
        error_bits(i) = error_bits(i) + sum(decoded_msg_bits_col ~= rand_msg_bits_col);
    end
end

ber_b = error_bits/(k*m*t_count);
ber_m = error_msg/(k*t_count);

figure;
semilogy(p_list, ber_b, '-o', 'LineWidth', 2); hold on;
semilogy(p_list, ber_m, '-s', 'LineWidth', 2);
grid on;
xlabel('channel transition probability  (p)');
ylabel('Error Rate');
title('BER and Message Error Rate vs channel transition probability in BSC');
legend('Bit Error Rate (BER)', 'Message Error Rate (MER)');
         



        

