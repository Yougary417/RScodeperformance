function [res] = gf_mul(x1, x2, n, alpha_power, index)
if x1 == 0 | x2 == 0
    res = uint16(0);
else 
alpha_index = mod((index(x1+1)+index(x2+1)-2), n);
res = uint16(logical(x1)).*uint16(logical(x2)).*uint16(alpha_power(alpha_index+1));
end
end
