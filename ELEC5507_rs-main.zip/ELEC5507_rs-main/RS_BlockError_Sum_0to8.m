
% MATLAB脚本：使用 i=0 到 8 求和计算块错误概率 + 图像 + 表格输出
clc; clear;

n = 255;
t = 8;
p_list = logspace(-5, -1, 100);
result_matrix = zeros(length(p_list), 3);

for idx = 1:length(p_list)
    p = p_list(idx);
    Ps = 1 - (1 - p)^8;

    P_success = 0;
    for i = 0:t
        P_success = P_success + nchoosek(n, i) * Ps^i * (1 - Ps)^(n - i);
    end
    P_block_error = 1 - P_success;
    result_matrix(idx, :) = [p, Ps, P_block_error];
end

% 打印表格（关键点）
format long e
highlight_idx = round(linspace(1, length(p_list), 5));
fprintf('\n简化公式结果表（i=0~8）：\n');
fprintf('       p            Ps           Block Error Probability\n');
for i = highlight_idx
    fprintf('%12.5e  %12.5e  %12.5e\n', result_matrix(i,1), result_matrix(i,2), result_matrix(i,3));
end

% 绘图
figure;
semilogy(result_matrix(:,1), result_matrix(:,3), '-b', 'LineWidth', 2);
grid on;
xlabel('Bit Error Probability (p)');
ylabel('Block Error Probability');
title('RS(255,239) Block Error (Sum i=0~8)');
xlim([1e-5, 1e-1]);

hold on;
semilogy(result_matrix(highlight_idx,1), result_matrix(highlight_idx,3), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
for i = highlight_idx
    x = result_matrix(i,1);
    y = result_matrix(i,3);
    label = sprintf('(%0.1e, %0.1e)', x, y);
    text(x*1.05, y, label, 'FontSize', 9);
end

saveas(gcf, 'RS_BlockError_Sum_0to8.png');
