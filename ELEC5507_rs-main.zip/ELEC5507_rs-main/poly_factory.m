% POLYNOMIAL OPERATIONS OVER GF(2^8)  
%  
% This MATLAB code translates the C "poly" file into MATLAB. It assumes you  
% already have the GF(2^8) arithmetic functions galois_fields.gf2p8_add, galois_fields.gf2p8_sub, galois_fields.gf2p8_mul,  
% galois_fields.gf2p8_div, galois_fields.gf2p8_neg, galois_fields.gf2p8_ind (etc.) available. In the original C code, these were  
% galois_fields.gf2p8_* functions, and galois_fields.gf2p8_t was the same as galois_fields.gf2p8_t. Here we treat them as  
% uint8 values and assume that galois_fields.gf2p8_* functions are the GF(2^8) operations.  
%  
% The polynomial "structure" is emulated by a MATLAB struct with two fields:  
%   poly.degree        : integer scalar for the polynomial degree  
%   poly.coeff(1, :)   : up to 255 coefficients, stored as uint8  
%  
% For clarity, we treat 0-based polynomial indexing in the code, so  
% poly.coeff(i+1) corresponds to the C code's coeff[i].  
%  
% Usage example:  
%   p1 = poly_clear();  
%   p1.coeff(1)   = uint8(5);   % constant term  
%   p1.coeff(2)   = uint8(7);   % x^1 coefficient  
%   p1.degree     = 1;  
%   p2 = poly_clear();   
%   p2.coeff(1)   = uint8(3);  
%   p2.coeff(2)   = uint8(1);  
%   p2.degree     = 1;  
%   pRes = poly_clear();  
%   pRes = poly_add(p1, p2, pRes);   
%   poly_print(pRes);  
%  
% List of functions defined in this file:  
%   poly_clear      : assign zero to polynomial  
%   poly_copy       : copy polynomial  
%   poly_normalize  : normalize polynomial degree  
%   poly_setdeg     : set polynomial degree by trailing coeffs  
%   poly_iszero     : return true if polynomial is zero  
%   poly_div        : polynomial division  
%   poly_print      : output polynomial to screen  
%   poly_subst      : evaluate polynomial at x  
%   poly_add        : polynomial addition  
%   poly_sub        : polynomial subtraction  
%   poly_mul        : polynomial multiplication  
%   poly_euclid     : extended Euclidean algorithm  
%   poly_neg        : negate polynomial  
%   poly_diff       : differentiate polynomial (formal derivative in GF(2^8))  

classdef poly_factory
    properties
        gf;
    end
    methods (Static)
        function polymal_test()
            obj = poly_factory();
        end
    end
    methods
        function obj = poly_factory()
            obj.gf = galois_fields();
        end
        
        % -------------------------------------------------------------------------  
        % CONSTANTS  
        % -------------------------------------------------------------------------  
        function val = POLY_SIZE(obj)  
            val = 255;  % Maximum number of coefficients  
        end  
          
        % -------------------------------------------------------------------------  
        % Create a "zero" polynomial struct.  
        % -------------------------------------------------------------------------  
        function p = poly_clear(obj)  
            p.degree = 0;  
            p.coeff  = zeros(1, obj.POLY_SIZE(), 'uint8');  
        end  
          
        % -------------------------------------------------------------------------  
        % Copy polynomial: to = from  
        % -------------------------------------------------------------------------  
        function to = poly_copy(obj, from)  
            % Ensure 'to' has enough space  
            to = obj.poly_clear();  
          
            % Copy up through from.degree  
            for i = 0:from.degree  
                to.coeff(i+1) = from.coeff(i+1);  
            end  
            % If to had more coefficients, ensure they are zeroed past the used range  
            for i = from.degree+1:obj.POLY_SIZE()-1  
                to.coeff(i+1) = uint8(0);  
            end  
          
            % Copy the degree  
            to.degree = from.degree;  
        end  
          
        % -------------------------------------------------------------------------  
        % Normalize polynomial degree  
        % -------------------------------------------------------------------------  
        function p = poly_normalize(obj, p)  
            d = p.degree;  
            while d > 0 && p.coeff(d+1) == 0  
                d = d - 1;  
            end  
            p.degree = d;  
        end  
          
        % -------------------------------------------------------------------------  
        % Set polynomial degree by trailing coefficients  
        % -------------------------------------------------------------------------  
        function p = poly_setdeg(obj, p)  
            d = obj.POLY_SIZE() - 1;   
            while d > 0 && p.coeff(d+1) == 0  
                d = d - 1;  
            end  
            p.degree = d;  
        end  
          
        % -------------------------------------------------------------------------  
        % Return true if polynomial is zero  
        % -------------------------------------------------------------------------  
        function val = poly_iszero(obj, p)  
            d = p.degree;  
            while d > 0 && p.coeff(d+1) == 0  
                d = d - 1;  
            end  
            val = (d == 0) && (p.coeff(d+1) == 0);  
        end  
          
        % -------------------------------------------------------------------------  
        % Polynomial division  
        %  
        % Returns:  
        %   status =  0 if successful  
        %           -1 if divisor is zero polynomial  
        %  
        %   quotient  = dividend / divisor  
        %   remainder = dividend mod divisor  
        % -------------------------------------------------------------------------  
        function [status, quotient, remainder] = poly_div(obj, dividend, divisor)  
            % If the divisor is zero, return -1  
            if obj.poly_iszero(divisor)  
                status = -1;  
                return;  
            else  
                status = 0;  
            end  
          
            % Work copy of dividend  
            dd = obj.poly_copy(dividend);  
          
            % Initialize quotient  
            quotient = obj.poly_clear();  
          
            qi = dd.degree - divisor.degree;  % degree(quotient)  
            if qi < 0  
                % If degree(dividend) < degree(divisor), quotient=0, remainder=dividend  
                remainder = obj.poly_copy(dd);  
                return  
            end  
            quotient.degree = qi;  
          
            % reciprocal of leading term in divisor  
            d = divisor.coeff(divisor.degree+1);  
          
            % Do the polynomial long division  
            for i = dd.degree:-1:divisor.degree  
                q = obj.gf.gf2p8_div(dd.coeff(i+1), d);  % single term of quotient  
                quotient.coeff(qi+1) = q;  
                qi = qi - 1;  
          
                % Subtract divisor*q from dd  
                for j = 0:divisor.degree  
                    idx = i - divisor.degree + j;  
                    dd.coeff(idx+1) = obj.gf.gf2p8_sub(dd.coeff(idx+1), obj.gf.gf2p8_mul(divisor.coeff(j+1), q));  
                end  
            end  
          
            % The remainder is what's left in dd  
            remainder = obj.poly_copy(dd);  
            remainder = obj.poly_normalize(remainder);  
            quotient  = obj.poly_normalize(quotient);  
        end  
          
        % -------------------------------------------------------------------------  
        % Print polynomial coefficients  
        % -------------------------------------------------------------------------  
        function poly_print(obj, p)  
          
            for i = 0:p.degree  
                c = p.coeff(i+1);  
                if c ~= 0 || i == 0  
                    % galois_fields.gf2p8_ind(c) might require a GF(2^8) index table if you have it  
                    idxVal = obj.gf.gf2p8_ind(c);  % requires galois_fields.gf2p8_ind in your workspace  
                end  
            end  
        end  
          
        % -------------------------------------------------------------------------  
        % Evaluate polynomial p at x:  sum_{i=0..degree} p.coeff[i]* x^i  
        % -------------------------------------------------------------------------  
        function val = poly_subst(obj, p, x)  
            val = uint8(0);  
            for i = p.degree:-1:0  
                val = obj.gf.gf2p8_add(obj.gf.gf2p8_mul(val, x), p.coeff(i+1));  
            end  
        end  
          
        % -------------------------------------------------------------------------  
        % Polynomial addition/subtraction helper  
        % p3 = p1 (+ or -) p2  
        % We pass a function handle galois_fields.gf2p8_op that is galois_fields.gf2p8_add or galois_fields.gf2p8_sub.  
        % -------------------------------------------------------------------------  
        function res = poly_addsub(obj, p1, p2, is_add)  
            res = obj.poly_clear();  
            i = 0;  
            d1 = p1.degree;  
            d2 = p2.degree;  
            while i <= max(d1,d2)  
                c1 = uint8(0);   
                c2 = uint8(0);  
                if i <= d1, c1 = p1.coeff(i+1); end  
                if i <= d2, c2 = p2.coeff(i+1); end  
          
                if is_add
                    res.coeff(i+1) = obj.gf.gf2p8_add(c1, c2);
                else
                    res.coeff(i+1) = obj.gf.gf2p8_sub(c1, c2);
                end
                i = i + 1;  
            end  
            res.degree = i-1;  
            res = obj.poly_normalize(res);  
        end  
          
        % -------------------------------------------------------------------------  
        % Polynomial addition: result = p1 + p2  
        % -------------------------------------------------------------------------  
        function result = poly_add(obj, p1, p2)  
            result = obj.poly_addsub(p1, p2, 1);  
        end  
          
        % -------------------------------------------------------------------------  
        % Polynomial subtraction: result = p1 - p2  
        % (In GF(2^8) galois_fields.gf2p8_sub == galois_fields.gf2p8_add, but we keep the function for clarity.)  
        % -------------------------------------------------------------------------  
        function result = poly_sub(obj, p1, p2)  
            result = obj.poly_addsub(p1, p2, 0);  
        end  
          
        % -------------------------------------------------------------------------  
        % Polynomial multiplication: result = p1 * p2  
        % -------------------------------------------------------------------------  
        function result = poly_mul(obj, p1, p2)  
            result = obj.poly_clear();  
            for i = 0:p1.degree  
                m = p1.coeff(i+1);  
                for j = 0:p2.degree  
                    t = obj.gf.gf2p8_mul(m, p2.coeff(j+1));  
                    result.coeff(i+j+1) = obj.gf.gf2p8_add(result.coeff(i+j+1), t);  
                end  
            end  
            result.degree = p1.degree + p2.degree;  
            result = obj.poly_normalize(result);  
        end  
          
        % -------------------------------------------------------------------------  
        % Extended Euclidean algorithm  
        %  
        % Input:  x, y, t (max deg of remainder)  
        % Output: a, b, c where a*x + b*y = c (degree(c) < t)  
        % -------------------------------------------------------------------------  
        function [a, b, c] = poly_euclid(obj, x, y, t)  
            % local polynomials  
            a0 = obj.poly_clear(); a0.coeff(1) = uint8(1);  % a0 = 1  
            a1 = obj.poly_clear();  
            a2 = obj.poly_clear();  
          
            b0 = obj.poly_clear();  
            b1 = obj.poly_clear(); b1.coeff(1) = uint8(1);  % b1 = 1  
            b2 = obj.poly_clear();  
          
            r0 = obj.poly_copy(x);  
            r1 = obj.poly_copy(y);  
          
            % while deg(r1) >= t  
            while r1.degree >= t  
                % r0 / r1 => q1, r2  
                [~, q1, r2] = obj.poly_div(r0, r1);  
          
                % a2 = a0 - q1*a1  
                tmp  = obj.poly_mul(q1, a1);  
                a2   = obj.poly_sub(a0, tmp);  
          
                % b2 = b0 - q1*b1  
                tmp  = obj.poly_mul(q1, b1);  
                b2   = obj.poly_sub(b0, tmp);  
          
                % shift polynomials  
                r0 = obj.poly_copy(r1);  
                r1 = obj.poly_copy(r2);  
          
                a0 = obj.poly_copy(a1);  
                a1 = obj.poly_copy(a2);  
          
                b0 = obj.poly_copy(b1);  
                b1 = obj.poly_copy(b2);  
            end  
          
            c = obj.poly_copy(r1);  
            a = obj.poly_copy(b1);  
            b = obj.poly_copy(a1);  
        end  
          
        % -------------------------------------------------------------------------  
        % Negate polynomial: p(x) -> -p(x). In GF(2^8), negation = identity.  
        % -------------------------------------------------------------------------  
        function p = poly_neg(obj, p)  
            for i = 0:p.degree  
                p.coeff(i+1) = obj.gf.gf2p8_neg(p.coeff(i+1));  
            end  
        end  
          
        % -------------------------------------------------------------------------  
        % Differentiating polynomial: df/dx in GF(2^8).  
        % In characteristic-2, derivative of x^i is i*x^(i-1) repeated i times =>   
        % effectively "i * a" is repeated XOR for a.   
        % -------------------------------------------------------------------------  
        function df = poly_diff(obj, f)  
            df = obj.poly_clear();  
            if f.degree <= 0  
                return;  
            end  
          
            for i = 1:f.degree  
                a  = f.coeff(i+1);  
                c  = uint8(0);  
                % add a i times  
                for j = 1:i  
                    c = obj.gf.gf2p8_add(c, a);  
                end  
                df.coeff(i) = c;  % i-th derivative term => x^(i-1)  
            end  
            df.degree = max(0, f.degree - 1);  
            df = obj.poly_normalize(df);  
        end  
    end
end