clc;
clear;

% RS(255,239) parameters
n = 255;              % Codeword length
k = 239;              % Message length
t = floor((n - k) / 2);  % Error correction capability (t = 8)

% Bit error probability values (log scale)
p_bit_values = logspace(-5, -1, 15);
block_error_probs = zeros(size(p_bit_values));

% Print header
fprintf('Bit Error Rate (p_bit)     Block Error Probability (P_E)\n');
fprintf('--------------------------------------------------------\n');

for idx = 1:length(p_bit_values)
    p_bit = p_bit_values(idx);

    % Convert bit error rate to symbol error probability (8 bits per symbol)
    p = 1 - (1 - p_bit)^8;

    % Compute probability of 0 to t errors (successful decoding)
    P_success = 0;
    for j = 0:t
        log_comb = gammaln(n+1) - gammaln(j+1) - gammaln(n-j+1);
        log_term = log_comb + j*log(p) + (n-j)*log(1 - p);
        P_success = P_success + exp(log_term);
    end

    % Block error probability = 1 - success probability
    P_E = 1 - P_success;

    % Save and print all values
    block_error_probs(idx) = P_E;
    fprintf('%12.1e\t\t%12.1e\n', p_bit, P_E);
end

% Plot all results
figure;
semilogx(p_bit_values, block_error_probs, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Bit Error Rate (p_{bit})');
ylabel('Block Error Probability P(E)');
title('RS(255,239) Block Error Probability vs Bit Error Rate');

% Set y-axis to log scale
set(gca, 'YScale', 'log');

