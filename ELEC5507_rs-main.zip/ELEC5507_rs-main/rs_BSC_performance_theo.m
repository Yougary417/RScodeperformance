clc;
clear;

% RS(255,239) parameters
n = 255;              % Codeword length
k = 239;              % Message length
t = floor((n - k) / 2);  % Error correction capability (t = 8)

% Bit error probability values (log scale)
p_bit_values = logspace(-3, -1, 12);
block_error_probs = zeros(size(p_bit_values));

% Print header
fprintf('Bit Error Rate (p_bit)     Block Error Probability (P_E)\n');
fprintf('--------------------------------------------------------\n');

for idx = 1:length(p_bit_values)
    p_bit = p_bit_values(idx);

    % Convert bit error rate to symbol error probability (8 bits per symbol)
    p = 1 - (1 - p_bit)^8;

    % Compute probability of 0 to t errors (successful decoding)
    P_success = 0;
    for j = 0:t
        log_comb = gammaln(n+1) - gammaln(j+1) - gammaln(n-j+1);
        log_term = log_comb + j*log(p) + (n-j)*log(1 - p);
        P_success = P_success + exp(log_term);
    end

    % Block error probability = 1 - success probability
    P_E = 1 - P_success;

    % Only print and store values within [1e-8, 1e0]
    if P_E >= 1e-10 && P_E <= 1e0
        block_error_probs(idx) = P_E;
        fprintf('%12.1e\t\t%12.1e\n', p_bit, P_E);
    else
        block_error_probs(idx) = NaN;  % Mark as invalid for plotting
    end
end

% Plot valid results
valid_idx = ~isnan(block_error_probs);
figure;
semilogx(p_bit_values(valid_idx), block_error_probs(valid_idx), '-o', 'LineWidth', 1.5);
grid on;
xlabel('Bit Error Rate (p_{bit})');
ylabel('Block Error Probability P(E)');
title('RS(255,239) Block Error Probability vs Message Error Rate');

% Set y-axis to log scale and limit from 1e-10 to 1e0
ylim([1e-8 1e0]);
set(gca, 'YScale', 'log');
yticks(10.^(-10:1:0));  % Show ticks from 1e-10 to 1e0
