
classdef cc

    methods (Static)
        function [trans, outputs] = generate_conv_matrices(constraint_length, gen_polynomials)  
        % GENERATE_CONV_MATRICES Generates transition and output matrices for convolutional codes  
        %  
        % Inputs:  
        %   constraint_length - Constraint length of the convolutional code (K)  
        %   gen_polynomials  - Array of generator polynomials as integers  
        %  
        % Outputs:  
        %   trans   - Transition matrix where trans(i,j) contains the input bit that  
        %             causes a transition from state i to state j (-1 if not possible)  
        %   outputs - Output matrix where outputs{i,j} contains the output  
        %             codeword for transition from state i to state j  
          
            % Number of states = 2^(K-1)  
            state_num = 2^(constraint_length - 1);  
              
            % Initialize matrices  
            trans = -1 * ones(state_num, state_num);  
            outputs = cell(state_num, state_num);  
              
            % Convert generator polynomials to binary representation  
            gen_polys_bin = zeros(length(gen_polynomials), constraint_length);  
            for i = 1:length(gen_polynomials)  
                gen_polys_bin(i, :) = de2bi(gen_polynomials(i), constraint_length, 'left-msb');  
            end  
              
            % Process each possible current state  
            for current_state = 0:state_num-1  
                % Get binary representation of current state  
                current_state_bin = de2bi(current_state, constraint_length-1, 'left-msb');  
                  
                % For each possible input bit (0 or 1)  
                for input_bit = 0:1  
                    % Calculate next state  
                    % Input bit as MSB, then shift current state right (drop LSB)  
                    next_state_bin = [input_bit, current_state_bin(1:end-1)];  
                    next_state = bi2de(next_state_bin, 'left-msb');  
                      
                    % Calculate output bits for this transition  
                    output = zeros(1, length(gen_polynomials));  
                    for g = 1:length(gen_polynomials)  
                        % Create shift register state with input bit as MSB  
                        shift_reg = [input_bit, current_state_bin];  
                          
                        % XOR the bits where the generator polynomial has 1s  
                        output(g) = mod(sum(shift_reg .* gen_polys_bin(g, :)), 2); 
                    end  
                      
                    % Update transition and output matrices  
                    % Note: Adding 1 to indices since MATLAB is 1-indexed  
                    trans(current_state+1, next_state+1) = input_bit;  
                    outputs{current_state+1, next_state+1} = output;  
                end  
            end  
        end 

        function encoded_output = conv_encode(message, constraint_length, outputs, output_size)  
        % CONV_ENCODE Encodes a binary message using a convolutional code  
        %  
        % Inputs:  
        %   message         - Binary message sequence to encode (already tail-padded)  
        %   constraint_length - Constraint length of the convolutional code  
        %   outputs         - Output matrix where outputs{i,j} contains the output  
        %                     codeword for transition from state i-1 to state j-1  
        %   output_size     - inverse code rate 
        %  
        % Outputs:  
        %   encoded_output  - Encoded output sequence  
          
            % Default initial state is 0 if not provided  
            initial_state = 0;  
             
            % Initialize variables  
            message_length = length(message);  
            state = initial_state;  
              
            % Initialize encoded output  
            encoded_output = zeros(message_length, output_size);  
              
            % Encode each bit of the message  
            for i = 1:message_length  
                input_bit = message(i);  
                  
                % Calculate next state directly  
                state_bits = de2bi(state, constraint_length-1, 'left-msb');  
                next_state_bits = [input_bit, state_bits(1:end-1)];  
                next_state = bi2de(next_state_bits, 'left-msb');  
                  
                % Get the output for this transition (adding 1 for MATLAB 1-indexing)  
                output = outputs{state+1, next_state+1};  
                  
                if isempty(output)  
                    error('No valid output for transition from state %d to state %d', state, next_state);  
                end  
                  
                encoded_output(i, :) = output;  
                  
                % Update state  
                state = next_state;  
            end  
              
            % Reshape to a single row  
            % encoded_output = reshape(encoded_output', 1, []);  
        end 

        function distance = diff_hard(expected, observed)
            expected = cell2mat(expected);

            observed_hard = round(observed);
            element_diff = abs(expected - observed_hard);
            distance = sum(element_diff);
        end

        function distance = diff_soft(expected, observed)
            expected = cell2mat(expected);
            % map 0 to +1, 1 to -1
            for i = 1:2
                if expected(i) == 0
                    expected(i) = 1;
                else
                    expected(i) = -1;
                end
            end
            % euclidean
            element_diff = (expected - observed).^2;
            distance = sum(element_diff);
        end
        
        function [decoded_msg, path, num_errors] = viterbi_decode(state_num, trans, outputs, obs, diff)  
        % VITERBI_DECODE Decodes a convolutional code using the Viterbi algorithm  
        %  
        % Inputs:  
        %   state_num - Total number of states in the trellis  
        %   trans     - Transition matrix where trans(i,j) contains the input that  
        %               causes a transition from state i to state j  
        %   outputs   - Output matrix where outputs(i,j) contains the output  
        %               codeword for transition from state i to state j  
        %   obs       - Sequence of observed codewords, with each row
        %               corresponding to an output pair
        %   diff      - Function handle that computes the distance between  
        %               two codewords: diff(expected, observed)  
        %  
        % Outputs:  
        %   decoded_msg - The decoded message sequence  
        %   path        - The most likely state path through the trellis  
          
            % Length of observation sequence  
            obs_length = length(obs); 
              
            % Initialize the trellis  
            % Each column represents a time step, each row represents a state  
            survivor_path = zeros(state_num, obs_length);  
            path_metric = inf(state_num, obs_length);  
              
            % Initialize path metrics (assume we start at state 1)  
            path_metric(1, 1) = 0;  
            for i = 2:state_num  
                path_metric(i, 1) = inf;  
            end  
              
            % Forward pass - compute path metrics  
            for t = 2:obs_length  
                for current_state = 1:state_num  
                    min_metric = inf;  
                    best_prev_state = 0;  
                      
                    % Check all possible previous states  
                    for prev_state = 1:state_num
                        % if going from the previous state is possible, AND
                        % the transition is valid
                        if ~isfinite(path_metric(prev_state, t-1)) || trans(prev_state, current_state) < 0
                            continue
                        end
                        expected_output = outputs(prev_state, current_state);  
                        if isempty(expected_output) 
                            error("no output from %d to %d. check if transition or output matrices are correct.", prev_state, current_state);
                        end
 
                        % Calculate metric for this path  
                        distance = diff(expected_output, obs(t-1, :));  
                        metric = path_metric(prev_state, t-1) + distance;  
                          
                        % in this case, we are preferring transitioning to lower state, than higher ones. 
                        if metric < min_metric  
                            min_metric = metric;  
                            best_prev_state = prev_state;  
                        end  

                    end  
                      
                    % Update the trellis  
                    if best_prev_state > 0  
                        path_metric(current_state, t) = min_metric;  
                        survivor_path(current_state, t) = best_prev_state;  
                    end  
                end  
            end  
              
            % Traceback - find the most likely path  
            path = zeros(1, obs_length);  
              
            % Find the final state with minimum metric  
            num_errors = min(path_metric(:, obs_length));
            [~, path(obs_length)] = min(path_metric(:, obs_length));  
              
            % Trace back through the trellis  
            for t = obs_length:-1:2  
                path(t-1) = survivor_path(path(t), t);  
            end  
              
            % Decode the message bits from the path  
            decoded_msg = zeros(1, obs_length);  
            for t = 1:obs_length-1  
                current_state = path(t);  
                next_state = path(t+1);  
                decoded_msg(t) = trans(current_state, next_state);  
            end 
            % padded with zeros. all good!
            decoded_msg(obs_length) = 0;
        end 

        function cc_test()
            constraint_len = 7;
            % polynomials
            g0 = 79; 
            g1 = 109;

            [trans, outputs] = cc.generate_conv_matrices(constraint_len, [g0, g1]);

            % test with bit messages for now
            message = [1, 0, 1, 0];
            message_padded = [message, zeros(1, constraint_len - 1)];

            message_padded

            codeword = cc.conv_encode(message_padded, constraint_len, outputs, 2);

            %codeword(1, :)

            % octal for the library function
            ref_conv = poly2trellis(constraint_len, [117, 155]);
            ref_codeword = convenc(message_padded, ref_conv);

            codeword

            codeword_3d = zeros(2, 10, 2);
            codeword_3d(1, :, :) = codeword;
            codeword_3d(1, :, :)
            codeword_3d(2, :, :)

            ref_codeword_reshaped = transpose(reshape(ref_codeword, 2, []));
            ref_codeword_reshaped

            isequal(codeword, ref_codeword_reshaped)
            %ref_codeword
            % introduce error
            codeword(2, 2) = ~codeword(2, 2);
            ref_codeword(4) = ~codeword(4);

            [decoded_msg, path, num_errors] = cc.viterbi_decode(length(trans), trans, outputs, codeword, @cc.diff_hard); 

            ref_decoded = vitdec(ref_codeword, ref_conv, length(codeword), "term", "hard");

            decoded_msg
            num_errors

            ref_decoded
        end
    end
end
