% GF(2^8) arithmetic in MATLAB  
%  
% This code replicates the functionality of the C code given, including:  
%   • Initialization of index and power tables  
%   • Addition/Subtraction (XOR)  
%   • Multiplication/Division  
%   • Negation  
%   • Finding indices and powers (log/exp)  
%  
% Usage:  
%   [gf2p8Index, gf2p8Power] = gf2p8_init();  
%   z = gf2p8_add(x, y);  
%   z = gf2p8_sub(x, y);  
%   idx = gf2p8_ind(x, gf2p8Index);  
%   val = gf2p8_pow(x, gf2p8Power);  
%   z = gf2p8_mul(x, y, gf2p8Index, gf2p8Power);  
%   z = gf2p8_recip(x, gf2p8Index, gf2p8Power);  
%   z = gf2p8_div(x, y, gf2p8Index, gf2p8Power);  
%   z = gf2p8_neg(x);  
%  
% Note:   
%   x and y should be uint8 values in the range [0, 255].  
%   gf2p8Index and gf2p8Power are lookup tables returned by gf2p8_init(). 
 

classdef galois_fields
    properties
        gf2p8Index;
        gf2p8Power;
    end
    methods
        %function [gf2p8Index, gf2p8Power] = gf2p8_init() 
        %function [idx, power] = gf2p8_init(obj)
        function obj = galois_fields()
        %GF2P8_INIT Initialize the index (log) and power (exp) tables for GF(2^8).  
          
            GF2P8_ELEMENT = 256;        % Number of elements in GF(2^8)  
            b = uint16(hex2dec('1D'));   % Irreducible polynomial (x^8 = x^4 + x^3 + x^2 + 1)  
          
            % Allocate tables  
            obj.gf2p8Index = zeros(GF2P8_ELEMENT,1, 'uint8');  
            obj.gf2p8Power = zeros(GF2P8_ELEMENT,1, 'uint8');  
          
            n = uint16(1);  % generator value "a^0"  
          
            % Build index (log) and power (exp) tables  
            % i runs from 0 to 254 (GF2P8_ELEMENT - 2)  
            for i = 0 : (GF2P8_ELEMENT - 2)  
                obj.gf2p8Index(n + 1) = uint8(i);   % log:   index_of( a^i ) = i  
                obj.gf2p8Power(i + 1)         = n;         % power: power_of( i )   = a^i  
          
                % Multiply n by x (i.e., shift left once) within GF(2^8)  
                n = bitshift(n, 1);  
          
                % If overflow beyond 8 bits, reduce with polynomial b  
                if n > 255  
                    n = bitxor(bitand(n, uint16(255)), b);  
                end  
            end  
          
            % Special cases  
            obj.gf2p8Index(1)           = uint8(255);  % log(0) is undefined; store 255  
            obj.gf2p8Power(255 + 1)     = uint8(1);    % a^255 = 1  
        end  
          
        function z = gf2p8_add(obj, x, y)  
        %GF2P8_ADD Addition in GF(2^8) (same as bitwise XOR).  
            z = bitxor(x, y);  
        end  
          
        function z = gf2p8_sub(obj, x, y)  
        %GF2P8_SUB Subtraction in GF(2^8) (identical to addition).  
            z = obj.gf2p8_add(x, y);  
        end  
          
        function idx = gf2p8_ind(obj, x)  
        %GF2P8_IND Return the discrete log index:  y where a^y = x.  
        %          If x = 0, this will return 255 in our table convention.  
            idx = obj.gf2p8Index(double(x) + 1);  
        end  
          
        function val = gf2p8_pow(obj, x)  
        %GF2P8_POW Return a^x in GF(2^8) given the exponent x.  
            val = obj.gf2p8Power(double(x) + 1);  
        end  
          
        function z = gf2p8_mul(obj, x, y)  
        %GF2P8_MUL Multiplication in GF(2^8).  
            if x == 0 || y == 0  
                z = uint8(0);  
            else  
                % (log(x) + log(y)) mod 255  
                ind = double(obj.gf2p8_ind(x)) + double(obj.gf2p8_ind(y));  
                ind = mod(ind, 255);  
                z = obj.gf2p8_pow(uint8(ind));  
            end  
        end  
          
        function z = gf2p8_recip(obj, x)  
        %GF2P8_RECIP Return the multiplicative inverse y of x where x*y = 1.  
            if x <= 1  
                % 0 -> 0, 1 -> 1  
                z = x;   
            else  
                % a^(255 - log(x))  
                idx = 255 - double(obj.gf2p8_ind(x));  
                z = obj.gf2p8_pow(uint8(idx));  
            end  
        end  
          
        function z = gf2p8_div(obj, x, y)  
        %GF2P8_DIV Division in GF(2^8): x / y = x * (1 / y).  
            z = obj.gf2p8_mul(x, obj.gf2p8_recip(y));  
        end  
          
        function z = gf2p8_neg(obj, x)  
        %GF2P8_NEG Negation in GF(2^8). For characteristic-2 fields, x == -x.  
            z = x;  
        end  
    end
end
