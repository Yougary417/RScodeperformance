
% i=9 到 255 
clc; clear;

n = 255;
t = 8;
p_list = logspace(-5, -1, 100);
result_matrix = zeros(length(p_list), 3);

for idx = 1:length(p_list)
    p = p_list(idx);
    Ps = 1 - (1 - p)^8;

    block_error = 0;
    for i = (t+1):n
        block_error = block_error + nchoosek(n, i) * Ps^i * (1 - Ps)^(n - i);
    end
    result_matrix(idx, :) = [p, Ps, block_error];
end

% print
format long e
highlight_idx = round(linspace(1, length(p_list), 5));
fprintf('\n正规公式结果表（i=9~255）：\n');
fprintf('       p            Ps           Block Error Probability\n');
for i = highlight_idx
    fprintf('%12.5e  %12.5e  %12.5e\n', result_matrix(i,1), result_matrix(i,2), result_matrix(i,3));
end

% figure
figure;
semilogy(result_matrix(:,1), result_matrix(:,3), '-r', 'LineWidth', 2);
grid on;
xlabel('Bit Error Probability (p)');
ylabel('Block Error Probability');
title('RS(255,239) Block Error (Sum i=9~255)');
xlim([1e-5, 1e-1]);

hold on;
semilogy(result_matrix(highlight_idx,1), result_matrix(highlight_idx,3), 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b');
for i = highlight_idx
    x = result_matrix(i,1);
    y = result_matrix(i,3);
    label = sprintf('(%0.1e, %0.1e)', x, y);
    text(x*1.05, y, label, 'FontSize', 9);
end


