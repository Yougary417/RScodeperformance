classdef e2e
    % class for linking rs, byte interleave, and cc together.
    properties (Constant)
        % reed-solomon
        rs_N = 255;
        rs_K = 239;
        rs_primpoly = 285; % X8 + X4 + X3 + X2 + 1;
        % byte interleave
        interleaver_rows = 10;
        % cc
        cc_g0_dec = 79; 
        cc_g1_dec = 109;
        cc_g0_oct = 117; % library functions need octal for some reason :shrug:
        cc_g1_oct = 155;
        cc_const_len = 7;
    end

    methods (Static)
        function rs_code_block = rs_encode_block(message_block)
            if ~ismatrix(message_block)  
                error('block must be matrix');  
            end
            [rows, cols] = size(message_block); 
            if cols ~= e2e.rs_K
                error("message length %d doesn't match %d", cols, e2e.rs_K);
            end
            if rows ~= e2e.interleaver_rows
                warning("number of message words %d may not be supported", rows);
            end

            rs_code_block = zeros(rows, e2e.rs_N);
            rs_gp_n = e2e.rs_N - e2e.rs_K;
            my_genpoly = rs.make_gen_poly(rs_gp_n, 1);
            for row = 1:rows
                rs_code_block(row, :) = rs.rs_encode(message_block(row, :), e2e.rs_N, e2e.rs_K, my_genpoly);
            end
        end

        function [message_block, numerrs] = rs_decode_block(rs_code_block)
            if ~ismatrix(rs_code_block)  
                error('block must be matrix');  
            end
            [rows, cols] = size(rs_code_block); 
            if cols ~= e2e.rs_N
                error("rs codeword length %d doesn't match %d", cols, e2e.rs_N);
            end
            if rows ~= e2e.interleaver_rows
                warning("number of message words %d may not be supported", rows);
            end

            message_block = zeros(rows, e2e.rs_K);
            numerrs = zeros(rows, 1); % records errors for each row decoded
            rs_gp_n = e2e.rs_N - e2e.rs_K;
            my_genpoly = rs.make_gen_poly(rs_gp_n, 1);
            for row = 1:rows
                [message_block(row, :), numerrs(row)] = rs.rs_decode(rs_code_block(row, :), e2e.rs_N, e2e.rs_K, my_genpoly);
            end
        end

        function cc_msg = cc_interleave_reshape(rs_code_block, zeros_tail)
            % zeros_tail - whether tail padding is added after every word,
            % or only after the entire block.
            if ~ismatrix(rs_code_block)  
                error('block must be matrix');  
            end
            [rows, cols] = size(rs_code_block); 
            if cols ~= e2e.rs_N
                error("rs codeword length %d doesn't match %d", cols, e2e.rs_N);
            end

            interleaved = rs_cc.byteInterleave(rs_code_block, rows);
            interleaved_bin = rs_cc.bytesToBits(interleaved);
            
            if zeros_tail
                interleaved_padded = rs_cc.addTailZeros(interleaved_bin, e2e.cc_const_len);
                cc_msg = interleaved_padded;
            else
                % manually add zeros.
                % transpose, for row major order
                cc_msg = zeros(1, rows * cols * 8 + e2e.cc_const_len - 1);
                cc_msg(1, :) = [reshape(interleaved_bin', 1, []), zeros(1, e2e.cc_const_len - 1)];
            end
        end

        function rs_code_block = cc_interleave_reshape_inv(cc_msg, zeros_tail)
            % doing some sanity checks
            if ~ismatrix(cc_msg)  
                error('block must be matrix');  
            end
            [rows, cols] = size(cc_msg);
            if zeros_tail % block matrix. 
                assert(rows == e2e.rs_N);
                assert(mod(cols - (e2e.cc_const_len - 1), 8) == 0); 
                actual_cols = (cols - (e2e.cc_const_len - 1)) / 8;
                if actual_cols ~= e2e.interleaver_rows
                    warning("number of message words %d may not be supported", actual_cols);
                end
                interleaved_bin = rs_cc.removeTailZeros(cc_msg, e2e.cc_const_len);
            else % line matrix
                assert(rows == 1); 
                assert(mod(cols - (e2e.cc_const_len - 1), 8) == 0); 
                total_cols = (cols - (e2e.cc_const_len - 1)) / 8;
                assert(mod(total_cols, e2e.rs_N) == 0);
                actual_cols = total_cols / e2e.rs_N;
                if actual_cols ~= e2e.interleaver_rows
                    warning("number of message words %d may not be supported", actual_cols);
                end
                total_cols_bin = total_cols * 8;
                interleaved_bin_reshaped = cc_msg(1, 1:total_cols_bin);
                % as before, transpose
                % interleaved_bin should have 255 rows, so when reshaping
                % have 255 cols
                interleaved_bin = reshape(interleaved_bin_reshaped, [], e2e.rs_N)';
            end

            interleaved = rs_cc.bitsToBytes(interleaved_bin);
            rs_code_block = rs_cc.byteInterleave_inv(interleaved, actual_cols);
        end

        function cc_code_block = cc_encode_block(cc_msg)
            if ~ismatrix(cc_msg)  
                error('block must be matrix');  
            end
            [rows, cols] = size(cc_msg);
            [~, outputs] = cc.generate_conv_matrices(e2e.cc_const_len, [e2e.cc_g0_dec, e2e.cc_g1_dec]);
            % 3d, to store the dual convolutional outputs
            cc_code_block = zeros(rows, cols, 2);
            for i = 1:rows
                cc_code_block(i, :, :) = cc.conv_encode(cc_msg(i, :), e2e.cc_const_len, outputs, 2);
            end
        end

        function [cc_msg, numerrs] = cc_decode_block(cc_code_block, diff)
            if ndims(cc_code_block) ~= 3
                error("block must be 3d");
            end
            [rows, cols, depth] = size(cc_code_block);
            assert(depth == 2);
            cc_msg = zeros(rows, cols);
            numerrs = zeros(rows, 1);
            [trans, outputs] = cc.generate_conv_matrices(e2e.cc_const_len, [e2e.cc_g0_dec, e2e.cc_g1_dec]);
            for i = 1:rows
                individual_block = zeros(cols, depth);
                for j = 1:cols
                    for k = 1:depth
                        individual_block(j, k) = cc_code_block(i, j, k);
                    end
                end
                [decoded_msg, ~, num_errors] = cc.viterbi_decode(length(trans), trans, outputs, individual_block, diff); 
                cc_msg(i, :) = decoded_msg;
                numerrs(i) = num_errors;
            end
        end

        function cc_code_stream = cc_block_to_stream(cc_code_block)
            if ndims(cc_code_block) ~= 3
                error("block must be 3d");
            end
            [rows, cols, depth] = size(cc_code_block);
            cc_code_stream = zeros(1, numel(cc_code_block));
            idx = 1;
            for i = 1:rows
                for j = 1:cols
                    for k = 1:depth
                        cc_code_stream(idx) = cc_code_block(i, j, k);
                        idx = idx + 1;
                    end
                end
            end
        end

        function cc_code_block = cc_stream_to_block(cc_code_stream, zeros_tail)
            if ~ismatrix(cc_code_stream)  
                error('block must be matrix');  
            end
            [rows, cols] = size(cc_code_stream);
            assert(rows == 1);
            if ~zeros_tail % 1 row, 2 depth
                actual_num_cols = cols / 2;
                actual_num_rows = 1;
            else
                actual_num_cols = cols / (2 * e2e.rs_N); % depth * rows
                actual_num_rows = e2e.rs_N;
            end
            
            cc_code_block = zeros(actual_num_rows, actual_num_cols, 2);
            idx = 1;
            for i = 1:actual_num_rows
                for j = 1:actual_num_cols
                    for k = 1:2
                        cc_code_block(i, j, k) = cc_code_stream(idx);
                        idx = idx + 1;
                    end
                end
            end
        end

        function rs_block_encode_decode_test()
            messages = zeros(10, 239);
            for i = 1:10
                for j = 1:239
                    messages(i, j) = mod((i - 1 + j), 256); %uint8
                end
            end
            cc_tail_zeros = true;

            % step 1: rs encode
            codewords = e2e.rs_encode_block(messages);
            decoded_msgs = e2e.rs_decode_block(codewords);

            assert(isequal(messages, decoded_msgs));

            % step 2: interleave, and transform from byte to bit
            cc_msg = e2e.cc_interleave_reshape(codewords, cc_tail_zeros);
            codewords_interleave_res = e2e.cc_interleave_reshape_inv(cc_msg, cc_tail_zeros);

            assert(isequal(codewords, codewords_interleave_res));

            % step 3: cc encode
            cc_codewords = e2e.cc_encode_block(cc_msg);
            cc_msg_decoded = e2e.cc_decode_block(cc_codewords, @cc.diff_hard);

            assert(isequal(cc_msg, cc_msg_decoded));

            % step 4: transform into a single array, to feed into the
            % channel for testing
            cc_code_stream = e2e.cc_block_to_stream(cc_codewords);
            cc_codeword_res = e2e.cc_stream_to_block(cc_code_stream, cc_tail_zeros);

            assert(isequal(cc_codewords, cc_codeword_res));
        end
    end
end