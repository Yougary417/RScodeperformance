clear; clc;

% Start parallel pool if not already started
if isempty(gcp('nocreate'))
    parpool;  % Use all available cores by default
end

% Reed-Solomon parameters
rs_N = 255;
rs_K = 239;
primpoly = 285;
rs_gp_n = rs_N - rs_K;
t = rs_gp_n / 2;
m = 8;  % Bits per symbol (GF(2^8))

% Custom generator polynomial
genpoly = rs.make_gen_poly(rs_gp_n, 0);

% BSC error probabilities (log-spaced)
p_values = logspace(-3, -1, 12);
num_trials = 30000;  % Number of trials per p value

% Preallocate result arrays
BER = zeros(size(p_values));
MER = zeros(size(p_values));

for idx = 1:length(p_values)
    p = p_values(idx);

    % Local accumulators for each trial
    total_bit_errors = zeros(1, num_trials);
    total_msg_errors = zeros(1, num_trials);
    total_bits = zeros(1, num_trials);

    parfor trial = 1:num_trials
        % Generate random message
        msg = randi([0, 255], 1, rs_K);
        codeword = rs.rs_encode(msg, rs_N, rs_K, genpoly);

        % Convert codeword to bits
        bits = de2bi(codeword, m, 'left-msb')';
        bits_col = bits(:)';  % Flatten to row vector

        % BSC channel: bit flipping with probability p
        flipped_bits_col = xor(bits_col, rand(size(bits_col)) < p);
        flipped_bits = reshape(flipped_bits_col, m, [])';
        rx_symbols = bi2de(flipped_bits, 'left-msb');

        % Decode received symbols
        [decoded_msg, decode_status] = rs.rs_decode(rx_symbols, rs_N, rs_K, genpoly);

        % Compare decoded and original bits
        orig_bits = de2bi(msg, m, 'left-msb')';
        orig_bits_col = orig_bits(:)';

        decoded_bits = de2bi(decoded_msg, m, 'left-msb')';
        decoded_bits_col = decoded_bits(:)';

        % Count bit errors
        bit_errors = sum(orig_bits_col ~= decoded_bits_col);
        total_bit_errors(trial) = bit_errors;
        total_bits(trial) = length(orig_bits_col);

        % Count message error if decoded symbols mismatch
        if any(decoded_msg' ~= msg)
            total_msg_errors(trial) = 1;
        end
    end

    % Aggregate results
    BER(idx) = sum(total_bit_errors) / sum(total_bits);
    MER(idx) = sum(total_msg_errors) / num_trials;

    fprintf("p = %.1e, MER = %.3e, BER = %.3e\n", p, MER(idx), BER(idx));
end

% Visualization
figure;
loglog(p_values, BER, '-o', 'DisplayName', 'Bit Error Rate'); hold on;
loglog(p_values, MER, '-x', 'DisplayName', 'Message Error Rate');
xlabel('Bit Flip Probability p (BSC)');
ylabel('Error Rate');
title('BER and MER vs. BSC Bit Flip Probability');
ylim([1e-8 1e0]);  % Set Y-axis range on log scale
legend('show');
grid on;

