% Clear workspace
clear; clc;

% Define SNR range in dB
snr_dB = 0:0.5:6;
num_snr = length(snr_dB);

% Number of Monte Carlo frames per SNR
num_frames = 1000;

% Initialize BER results
ber_results = zeros(1, num_snr);

% System parameters
rs_K = e2e.rs_K;
rs_N = e2e.rs_N;
cc_K = e2e.cc_const_len;
interleaver_rows = e2e.interleaver_rows;

% Bits per frame
bits_per_frame = rs_K * interleaver_rows * 8;

% Create convolutional trellis
trellis = poly2trellis(cc_K, [e2e.cc_g0_oct, e2e.cc_g1_oct]);

% Set traceback depth
tbl = 5 * (cc_K - 1);

% Enable parallel pool
if isempty(gcp('nocreate'))
    parpool;
end

% Main loop over SNR with parallel execution
parfor idx = 1:num_snr
    snr = snr_dB(idx);
    total_bit_errors = 0;
    total_bits = 0;

    for frame = 1:num_frames
        % Generate random message
        msg = randi([0, 255], interleaver_rows, rs_K, 'uint8');

        % RS encode
        rs_code = e2e.rs_encode_block(msg);

        % Interleave and convert to bitstream
        cc_input_bits = e2e.cc_interleave_reshape(rs_code, true);

        % Convolutional encode
        cc_encoded = e2e.cc_encode_block(cc_input_bits);

        % Flatten encoded output
        tx_stream = e2e.cc_block_to_stream(cc_encoded);

        % BPSK modulation: 0 -> -1, 1 -> +1
        tx_symbols = 2 * tx_stream - 1;

        % Add AWGN noise
        rx_symbols = awgn(tx_symbols, snr, 'measured');

        % Hard decision demodulation
        rx_bits = rx_symbols > 0;

        % Reshape to 3D convolutional block
        rx_block = e2e.cc_stream_to_block(rx_bits, true);

        % Decode convolutional code
        [cc_decoded_bits, ~] = e2e.cc_decode_block(rx_block, @cc.diff_hard);

        % De-interleave and convert to byte matrix
        rs_code_est = e2e.cc_interleave_reshape_inv(cc_decoded_bits, true);

        % RS decode
        [msg_est, ~] = e2e.rs_decode_block(rs_code_est);

        % Compute bit error rate
        tx_bits = reshape(de2bi(msg, 8, 'left-msb')', [], 1);
        rx_bits_est = reshape(de2bi(msg_est, 8, 'left-msb')', [], 1);
        bit_errors = sum(tx_bits ~= rx_bits_est);

        total_bit_errors = total_bit_errors + bit_errors;
        total_bits = total_bits + length(tx_bits);
    end

    % Save BER result for this SNR
    ber_results(idx) = total_bit_errors / total_bits;
    fprintf('SNR = %d dB, BER = %.5e\n', snr, ber_results(idx));
end

% Plot BER vs SNR curve
figure;
semilogy(snr_dB, ber_results, 'o-', 'LineWidth', 2);
xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
title('BER Performance of RS + CC System');
ylim([1e-6, 1e0]); % Set y-axis limits
grid on;
