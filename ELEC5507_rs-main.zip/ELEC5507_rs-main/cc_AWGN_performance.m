clear
clc

% === Convolutional Code Parameters ===
constraint_len = 7;
g0 = 79;   % octal 117
g1 = 109;  % octal 155
[trans, outputs] = cc.generate_conv_matrices(constraint_len, [g0, g1]);
state_num = size(trans, 1);
tail = constraint_len - 1;

% === Simulation Parameters ===
k = 1000;                   % Message length in bits
num_trials = 5e3;           % Trials per SNR point
EbN0_dB = 0:0.5:6;         % Eb/N0 in dB
EbN0 = 10.^(EbN0_dB / 10);  % Linear scale
R = 1/2;                    % Code rate for (2,1) convolutional code

BER = zeros(size(EbN0));
MER = zeros(size(EbN0));

% Start parallel pool if not started
if isempty(gcp('nocreate'))
    parpool('local');
end

% Loop over SNR points
for i = 1:length(EbN0)
    N0 = 1 / (2 * R * EbN0(i));
    sigma = sqrt(N0);

    bit_err_vec = zeros(1, num_trials);
    msg_err_vec = zeros(1, num_trials);

    % === Parallel simulation ===
    parfor t = 1:num_trials
        % Generate random message and pad with tail zeros
        msg = randi([0 1], 1, k);
        msg_pad = [msg, zeros(1, tail)];

        % Encode using custom encoder
        codeword = cc.conv_encode(msg_pad, constraint_len, outputs, 2);

        % BPSK modulation: 0 -> +1, 1 -> -1
        tx = 1 - 2 * codeword;

        % Add Gaussian noise
        noise = sigma * randn(size(tx));
        rx = tx + noise;

        % Soft-decision Viterbi decoding
        [decoded, ~, ~] = cc.viterbi_decode(state_num, trans, outputs, rx, @cc.diff_soft);
        decoded = decoded(1:k);  % remove tail

        % Count errors
        errors = sum(decoded ~= msg);
        bit_err_vec(t) = errors;
        msg_err_vec(t) = errors > 0;
    end

    BER(i) = sum(bit_err_vec) / (num_trials * k);
    MER(i) = sum(msg_err_vec) / num_trials;

    fprintf("Eb/N0 = %.1f dB | BER = %.5e | MER = %.4f\n", EbN0_dB(i), BER(i), MER(i));
end

% === Plot Results ===
figure;
semilogy(EbN0_dB, BER, '-ro', EbN0_dB, MER, '-bs', 'LineWidth', 2);
grid on;
xlabel('E_b/N_0 (dB)');
ylabel('Error Rate');
legend('Bit Error Rate (BER)', 'Message Error Rate (MER)', 'Location', 'southwest');
title('Convolutional Code (2,1,6) over AWGN (Soft-Decision): BER & MER');
ylim([1e-6 1e0]); 