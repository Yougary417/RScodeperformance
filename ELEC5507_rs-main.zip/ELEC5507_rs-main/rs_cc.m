

classdef rs_cc
    properties (Constant)
        rs_code_len = 255;
        interleaver_rows = 10;
    end

    methods (Static)
        function transposed_array = byteInterleave(input_array, num_rows)  
            % some sanity checks
            if ~ismatrix(input_array)  
                error('Input array must be matrix');  
            end
            [actual_rows, actual_cols] = size(input_array);  
            % check inputs.
            if actual_cols ~= rs_cc.rs_code_len  
                error('Input array must have exactly %d columns', rs_cc.rs_code_len);  
            end
            % sanity check for rows.
            if actual_rows ~= num_rows  
                error('Number of rows in input array (%d) does not match specified number (%d)', actual_rows, num_rows);  
            end
            % apparently, wimax supports 10 by default. We will use that
            % property as well.
            if num_rows ~= 10  
                warning('Number of rows is %d, but 10 is recommended for standard interleaving', num_rows);  
            end
              
            % Perform the transposition for interleaving  
            transposed_array = input_array';  
        end

        function transposed_array = byteInterleave_inv(input_array, num_cols)
            % same as above
            if ~ismatrix(input_array)  
                error('Input array must be matrix');  
            end
            [actual_rows, actual_cols] = size(input_array);  
            if actual_rows ~= rs_cc.rs_code_len  
                error('Input array must have exactly 255 rows');  
            end
            if actual_cols ~= num_cols  
                error('Number of rows in input array (%d) does not match specified number (%d)', actual_cols, num_cols);  
            end
            if num_cols ~= 10  
                warning('Number of rows is %d, but 10 is recommended for standard interleaving', num_cols);  
            end
            transposed_array = input_array';  
        end

        % send the bytes in big endian
        function bit_array = bytesToBits(byte_array)  
            [rows, cols] = size(byte_array);  
            bit_array = zeros(rows, cols * 8);  
              
            for r = 1:rows  
                for c = 1:cols  
                    byte_val = byte_array(r, c);  
                      
                    % Convert byte to 8 bits (MSB first)  
                    for bit_idx = 1:8  
                        bit_array(r, (c - 1) * 8 + bit_idx) = bitget(byte_val, 9-bit_idx);  
                    end
                end  
            end
        end
          
        function byte_array = bitsToBytes(bit_array)  
            [rows, bits] = size(bit_array);  
              
            if mod(bits, 8) ~= 0  
                error('bit array length %d, not multiple of 8!!', bits);  
            end  
              
            cols = bits / 8;  
            byte_array = zeros(rows, cols);  
              
            for r = 1:rows  
                for c = 1:cols  
                    byte_val = 0;  
                    for bit_idx = 1:8  
                        byte_val = byte_val + bit_array(r, (c - 1) * 8 + bit_idx) * 2^(8-bit_idx);  
                    end  
                    byte_array(r, c) = byte_val;  
                end  
            end  
        end  
          
        function padded_array = addTailZeros(input_array, constraint_length)  
            [rows, cols] = size(input_array);  
            padding_size = constraint_length - 1;  
            padded_array = zeros(rows, cols + padding_size);  
            % Copy the original data  
            padded_array(:, 1:cols) = input_array;  
        end
        
        function original_array = removeTailZeros(padded_array, constraint_length)
            [~, cols] = size(padded_array);  
            padding_size = constraint_length - 1;  
              
            if cols <= padding_size  
                error("Not enough columns, %d <= %d!!", cols, padding_size);  
            end
            
            original_cols = cols - padding_size;  
            original_array = padded_array(:, 1:original_cols);  
        end  

    end
end